package utilities;

import java.util.Random;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class Utils {

	public static void waitUntilPageLoad(WebDriver driver, int timeOut) {
		driver.manage().timeouts().implicitlyWait(timeOut, TimeUnit.SECONDS);
	}

	public static void mouseHoverElement(WebDriver driver, WebElement element) {
		Actions action = new Actions(driver);
		action.moveToElement(element).build().perform();
	}

	public static void mouseHoverElementClick(WebDriver driver, WebElement element) {
		Actions action = new Actions(driver);
		action.click(element).build().perform();
		waitUntilPageLoad(driver,100);
	}

	public static void clickByJavaScript(WebDriver driver, WebElement element) {
		final JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", element);
	}

	public static void sendTextByJavaScript(WebDriver driver, WebElement element, String num) {
		final JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[1].value = arguments[0]; ", num, element);
	}

	public static void sendTextByKeys(WebElement element, String num) {
		element.sendKeys(num);
	}
	
	public static void jsScrllDown(WebDriver driver) {
		final JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("window.scrollTo(0, document.body.scrollHeight)");
	}

	public static void jsScrllDownPartial(WebDriver driver) {
		final JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("scroll(0, 500);");
	}

	public static void jsScrollUp(WebDriver driver) {
		final JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("window.scrollTo(0, -document.body.scrollHeight)");
	}
	
	public static void switchIframe(WebDriver driver, WebElement element) {
		driver.switchTo().frame(element);
	}
	
	public static String getEmailString() {
        String emailChar = "abcdefghijklmnopqrstuvwxyz1234567890";
        StringBuilder emails = new StringBuilder();
        Random rnd = new Random();
        while (emails.length() < 10) { // length of the random string.
            int index = (int) (rnd.nextFloat() * emailChar.length());
            emails.append(emailChar.charAt(index));
        }
        String emailsStr = emails.toString();
        return emailsStr;

    }
	
	public static String getPasswordString() {
        String passwordChar = "abcdEFGHijklmNOPQRstuvwXYZ1234567890^$p*";
        StringBuilder pwds = new StringBuilder();
        Random rnd = new Random();
        while (pwds.length() < 10) { // length of the random string.
            int index = (int) (rnd.nextFloat() * passwordChar.length());
            pwds.append(passwordChar.charAt(index));
        }
        String passwordStr = pwds.toString();
        return passwordStr;

    }
	
	public static String getNumber() {
        String rndChar = "ABCDE67890";
        StringBuilder rndNum = new StringBuilder();
        Random rnd = new Random();
        while (rndNum.length() < 9) { // length of the random string.
            int index = (int) (rnd.nextFloat() * rndChar.length());
            rndNum.append(rndChar.charAt(index));
        }
        String rndStr = rndNum.toString();
        return rndStr;

    }
}