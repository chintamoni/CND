package pages;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;
import java.util.Properties;
import utilities.Utils;


public class DefinitionPage extends BasePage{

	static WebDriver driver=null;
	static Properties prpty=null;
	public static String appURL=null;
	public static String st1=null;
	public static String st2=null;
	public static String st3=null;
	
	/*Locators for CND*/
	
	@FindBy(xpath="*//input[@class='cnd-input cyp-search-autocomplete cnd-autocomplete']")
	static WebElement txtCNDSearch;
	
	@FindBy(xpath="*//input[@class='cnd-input cyp-search-autocomplete cnd-autocomplete']/following-sibling::div//li//*[contains(@class,'suggestion-title')]")
	static List<WebElement> lblCNDSuggestionTitle;
	
	@FindBy(xpath="*//input[@class='cnd-input cyp-search-autocomplete cnd-autocomplete']/following-sibling::div//li//*[contains(@class,'suggestion-address')]")
	static List<WebElement> lblCNDSuggestionAddress;
	
	@FindBy(xpath="//*[@id='vehicle-search-container']/div[4]/div/div[2]/span")
	static WebElement linkCNDEnterDate;
	
	@FindBy(xpath="//*[contains(@class,'mbsc-ic mbsc-ic-arrow-right5 mbsc-cal-next mbsc-cal-next-m mbsc-cal-btn mbsc-fr-btn mbsc-fr-btn-e')]")
	static WebElement linkCNDMonthNext;
	
	@FindBy(xpath="//*[contains(@class,'mbsc-ic mbsc-ic-arrow-right5 mbsc-cal-next mbsc-cal-next-m mbsc-cal-btn mbsc-fr-btn mbsc-fr-btn-e')]/preceding-sibling::div[@class='mbsc-cal-month']")
	static WebElement lblCNDMonth;
	
	@FindBy(xpath="//*[contains(@id,'mobiscroll')]/div/div[2]/div/div[1]/div/div/div[text()='2']")
	static WebElement lblCNDMonthDate;
	
	@FindBy(xpath="//*[@id='vehicle-search-container']//cnd-vehicle-card")
	static List<WebElement> cardCNDGetCard;
	
	@FindBy(xpath="//*[contains(@class,'cnd-panel cnd-hidden lg:cnd-block')]//div//div//div[contains(@class,'cnd-header')][2]")
	static WebElement cardCNDVehicleTitle;

	
	
	static Logger log = Logger.getLogger(DefinitionPage.class.getName());

	public DefinitionPage() {
		PropertyConfigurator.configure(System.getProperty("user.dir")+"\\src\\main\\java\\Resources\\logger.properties");
		BasePage bpage = new BasePage();
		log.info("Loading Properties..");
		prpty=bpage.loadPropertiesValue();
		driver=bpage.getBrowser(prpty.getProperty("cnd.vsbrowser"));
		log.info("Initialising browser: " + prpty.getProperty("cnd.vsbrowser"));
		log.info("Initialising page factory..");
		PageFactory.initElements(driver, this);
	}
	
	public static void launchBrowser(String URL)
	{
		log.info("Browser is launched");
		appURL=URL;
		driver.get(URL);
		Utils.waitUntilPageLoad(driver, 20);
		log.info("Browser is maximised");
		driver.manage().window().maximize();
		Utils.waitUntilPageLoad(driver, 50);
	} 
	
	public static void enteringText(String add)
	{
	/*Entering SearchText*/
	txtCNDSearch=driver.findElement(By.xpath("*//input[@class='cnd-input cyp-search-autocomplete cnd-autocomplete']"));
	txtCNDSearch.click();
	Utils.clickByJavaScript(driver, txtCNDSearch);
	txtCNDSearch.clear();
	txtCNDSearch=driver.findElement(By.xpath("*//input[@class='cnd-input cyp-search-autocomplete cnd-autocomplete']"));
    txtCNDSearch.sendKeys(add);
    Utils.waitUntilPageLoad(driver, 100);
	}
	public static void selectingAddress(String selAdd)
	{
	     /*Selecting Desired Address*/
	    	List<WebElement>lblCNDSuggestionTitles=driver.findElements(By.xpath("*//input[@class='cnd-input cyp-search-autocomplete cnd-autocomplete']/following-sibling::div//li//*[contains(@class,'suggestion-title')]"));
	       for(WebElement suggesstionTitle :lblCNDSuggestionTitles )
	       {
	    	   if(suggesstionTitle.getText().trim().equals(selAdd))
	    	   {
	    		   suggesstionTitle.click();
	    		   Utils.waitUntilPageLoad(driver, 300);
	    		   break;
	    	   }
	       }
	}
	
	public static void clickingOnVehicle(String selAdd)
	{
	     /*Clicking on Desired Vehicle*/
		String st1=null;
		String st2=null;
		String st3=null;
		String[] st = selAdd.split(" ");
		st1=st[0];
		st2=st[1];
		st3=st[2];
		Utils.jsScrllDownPartial(driver);
		Utils.waitUntilPageLoad(driver, 100);
		cardCNDGetCard=driver.findElements(By.xpath("//*[@id='vehicle-search-container']//cnd-vehicle-card"));
	       for(WebElement cndCard :cardCNDGetCard )
	       {
	    	   if(cndCard.getText().contains(st1)&&cndCard.getText().contains(st2)&&cndCard.getText().contains(st3))
	    	   {
	    		   Utils.mouseHoverElement(driver, cndCard);
	    		   Utils.clickByJavaScript(driver, cndCard);
	    		   Utils.waitUntilPageLoad(driver, 300);
	    		   break;
	    	   }
	       }
	}
	
	public static void verifyVehicle()
	{
	     /*Validate displayed vehicle*/
		Utils.waitUntilPageLoad(driver, 300);
		Utils.jsScrllDownPartial(driver);
		Utils.waitUntilPageLoad(driver, 100);
		cardCNDVehicleTitle=driver.findElement(By.xpath("//*[contains(@class,'cnd-panel cnd-hidden lg:cnd-block')]//div//div//div[contains(@class,'cnd-header')][2]"));
		if(cardCNDVehicleTitle.getText().equals(st1)&&cardCNDVehicleTitle.getText().equals(st2)&&cardCNDVehicleTitle.getText().equals(st3))
		{
			log.info("Correct Vehicle page is opened");
		}
	}
	
	protected static void closeDriver()
	{
		if(driver!=null)
		{
		driver.quit();
		log.info("Quitting all current browser sessions");
		}
	}

}
