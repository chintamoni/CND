package steps;

import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.DefinitionPage;

public class CND extends DefinitionPage{
	
	@Given("^user has initialised browser$")
	public void user_has_initialised_browser(){
	}

	@Given("^User is on the \"([^\"]*)\"$")
	public void User_is_on_the(String arg1){
		launchBrowser(arg1);
	}
	
	@When("User Entered \"([^\"]*)\"$")
	public void user_Entered_Bayshore_Drive_Byron_Bay_New_South_Wales(String st) {
		enteringText(st);
		}
	
	@When("User selected option {string}")
	public void user_selected_option(String string) {
	    // Write code here that turns the phrase above into concrete actions
		selectingAddress(string);
	}
	
	@When("User Selected pickdate {string},{string}")
	public void user_Selected_pickdate(String string, String string2) {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("User Selected returndate {string},{string}")
	public void user_Selected_returndate(String string, String string2) {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("User Clicked on the {string}")
	public void user_Clicked_on_the_Volkswagen_Transporter(String st4) {
		clickingOnVehicle(st4);
	}

	@Then("Vehicle Details are displayed")
	public void vehicle_Details_are_displayed() {
		verifyVehicle();
	}
	
	@After
	@Then("^closing browser after scenario execution$")
	public void closing_browser_after_scenario_execution(){
		closeDriver();
	}
}
